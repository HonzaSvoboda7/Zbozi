﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zbozi_WPF
{
    internal class EvidenceZB
    {
        List<Zbozi>Zbozis { get; set; }
    }
}
