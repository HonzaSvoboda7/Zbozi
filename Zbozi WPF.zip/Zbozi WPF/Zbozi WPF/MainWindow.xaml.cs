﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Zbozi_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Zbozi> Zbozis { get; set; }
        public MainWindow()
        {
            Zbozis = new();
            InitializeComponent();
            seznam.ItemsSource = Zbozis;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DialogPridat dialog = new(Zbozis);
            dialog.Closing += Dialog_Closing;
            dialog.ShowDialog();
        }
        private void Dialog_Closing(object? sender, EventArgs e)
        {
            seznam.ItemsSource = null;
            seznam.ItemsSource = Zbozis;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Zbozi? info = seznam?.SelectedItem as Zbozi ?? new Zbozi("Nenalezen", 0, 0, 0);
            MessageBox.Show($"{info.Id} {info.Nazev} {info.Pocet} {info.Cena}");
        }

       // private void Button_Click_2(object sender, RoutedEventArgs e)
       // {
        //    Zbozi? hledany = seznam?.SelectedItem as Zbozi;
        //    MessageBoxResult volba = MessageBox.Show($"Odebrat {hledany.Nazev}?", "Odebrat", MessageBoxButton.YesNo);
        //    if (volba == MessageBoxResult.Yes)
        //    {
        //        Zbozi.Remove(hledany);
        //        seznam.ItemsSource = null;
        //        seznam.ItemsSource = Zbozi;
        //    }
       // }
    }
}